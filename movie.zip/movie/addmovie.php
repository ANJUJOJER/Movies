
<?php


include("conn.php");

//Include the event calendar functions file

?>
<?php
session_start();
if(isset($_SESSION['username']))
{
	?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>NEOFLEX</title>
	<title>	<?php

?>

</title>
     <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link type="text/css" rel="stylesheet" href="jscript/style.css"/>
<link type="text/css" rel="stylesheet" href="jscript/bootstrap/css/bootstrap.css"/>
<link type="text/css" rel="stylesheet" href="jscript/bootstrap/css/bootstrap.min.css"/>
<script src="jscript/jquery.min.js"></script>
	  
	  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  
	  
	  <script src="sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="sweetalert/dist/sweetalert.css">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />






<style>
  
	  .button {
    background-color:#e7e7e7;
    border: none;
    color: white;
    padding: 6px 14px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 13px;
    margin: 6px 3px;
    cursor: pointer;
	  position: relative;
  top: -2px;
  left:925px;

	
}

a{
	
	color: #008CBA;
}
</style>


<script
src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script
src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js">
        </script>
<script>
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted)
disableBack() }
    });
</script>

	  
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
      <header class="main-header">
        <!-- Logo -->
        <a href="index.php" class="logo"><b>NEOFLEX</b></a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
			  
            
			  
			  
			  
     
			  
			  
			  
			  
       
			  
			  
			  
			  
			  
			  
			    <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="dist/img/admin.png" class="user-image" alt="User Image"/>
                  <span class="hidden-xs">Admin</span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="dist/img/admin.png" class="img-circle" alt="User Image" />
                    <p>
                     Admin
                      <small>Administrator</small>
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <li class="user-body">
                    
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    
                    <div class="pull-right">
                      <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      
      
      
      
      
      
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
		
		
		
     	<?php
		
       include("sidebar.php");
		?>
		
		
		
		
		
		
		
		
        <!-- /.sidebar -->
      </aside>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
       
   
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
     Create Movie
            <small></small>
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6">
              <!-- general form elements -->
              <div class="box box-primary">
			  
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
				
				
				<form method="post" enctype="multipart/form-data" action="#">
                    <table class="table no-border">
					
					
					
				 <tr>                                    

                                                    <td>
                                             <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Movie Title </label></td><td>
                                                        <input type="text" class="form-control"   style="width:300px"  id="f1-facebook" name="namea" required>
                                                    </div>
													
													
			
													</td>
													
													</tr>
													
													
													
											 <tr>                                    

                                                    <td>
                                             <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Movie Trailer Url - youtube or any hosted video </label></td><td>
                                                        <input type="text" class="form-control"   style="width:300px"  id="f1-facebook" name="turl" required>
                                                    </div>
													
													
			
													</td>
													
													</tr>
													
													
													 <tr>                                    

                                                    <td>
                                             <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Movie Url - youtube or any hosted video </label></td><td>
                                                        <input type="text" class="form-control"   style="width:300px"  id="f1-facebook" name="ourl" required>
                                                    </div>
													
													
			
													</td>
													
													</tr>
													
													<tr>                                    

                                                    <td>
                                             <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Thumbnail - icon image of the movie </label></td><td>
                                                        <input type="file" name="image1" />
                                                    </div>
													
													
			
													</td>
													
													</tr>
													
													
													
													<tr>                                    

                                                    <td>
                                             <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Poster - large banner image of the movie </label></td><td>
                                                        <input type="file" name="image" />
                                                    </div>
													
													
			
													</td>
													
													</tr>
													
													
													
													
													
													
													
														<tr>
                                                    <td>
                                                <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Long description</label></td><td>
                                                  <textarea rows="4" cols="45" name="longdes" type="text">

</textarea>
                                                    </div></td></tr>
													
													
														
														<tr>
                                                    <td>
                                                <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Short description</label></td><td>
                                                  <textarea rows="4" cols="45" name="shdes" type="text">

</textarea>
                                                    </div></td></tr>
													
													
													
													<tr>
													
										 		    <td>
                                                <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Actors - select multiple actors</label></td><td>
                                                     <?php
														$stb = "SELECT DISTINCT name FROM actor";
														$re=mysqli_query($conn,$stb);
														
														
														?>
														<select name="act[]" id="sel" class="form-control" style="width:250px;" multiple>
														<option value="0">SELECT ACTOR</option>
														<?php while($data = mysqli_fetch_assoc($re)){ ?>
														<option value="<?php echo $data['name'];?>"> <?php echo $data['name'];?>

														</option>
														
														<?php }?> 
                                                        </select>
                                                    </div></td>
													
													
													
													
													
													</tr>
													
													
													
																<tr>
													
										 		    <td>
                                                <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Genre - genre must be selected</label></td><td>
                                                     <?php
														$stb = "SELECT DISTINCT name FROM genre";
														$re=mysqli_query($conn,$stb);
														
														
														?>
														<select name="genre" id="genre" class="form-control" style="width:250px;" >
														
														
														<?php while($data = mysqli_fetch_assoc($re)){ ?>
														<option value="<?php echo $data['name'];?>"> <?php echo $data['name'];?>

														</option>
														
														<?php }?> 
                                                        </select>
                                                    </div></td>
													
													
													
													
													
													</tr><tr>
													
										 		    <td>
                                                <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Publishing Year - year of publishing time</label></td><td>
                                                    
														<select name="year" id="year" class="form-control" style="width:250px;" >
														
														<option value="2015">2015</option>
														
														<option value="2016">2016</option>
														
														<option value="2017">2017</option>
														
														
														<option value="2018">2018</option>
														
													
														<option value="2019">2019</option>
														
                                                        </select>
                                                    </div></td>
													
													
													
													
													
													</tr>
													
													
													
						<tr>
													
										 		    <td>
                                                <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Rating - star rating of the movie</label></td><td>
                                                    
														<select name="star" id="star" class="form-control" style="width:250px;" >
														
														<option value="0">0</option>
														
														<option value="1">1</option>
														
														<option value="2">2</option>
														
														
														<option value="3">3</option>
														
													
														<option value="4">4</option>
														<option value="5">5</option>
                                                        </select>
                                                    </div></td>
													
													
													
													
													
													</tr>
													
														<tr>
													
										 		    <td>
                                                <div class="form-group">
                                                        <label class="m-t-0"  for="f1-facebook">Featured - featured movie will be shown in home page</label></td><td>
                                                    
														<select name="fect" id="fect" class="form-control" style="width:250px;" >
														
														<option value="Yes">Yes</option>
														
														<option value="No">No</option>
														
														
                                                        </select>
                                                    </div></td>
													
													
													
													
													
													</tr>
													
													
													
								
													
													
													
													 
													
													
													
													
													
													
													
													
													
													
													
													
													
													
													
													
													
													
													
													
                                                  
                                                    
                                                          </table>
          
                     
					 
					  <div class="box-footer">
                    <button type="submit"  name="submit" class="btn btn-primary" >Save Informations</button>
                  </div>
					 
					 
					 
					 
					
					 
					 </div>
           
           </form>
		   
		   
		   
		   
		   
		   	
				<script>
$(document).ready(function(){
 $('#framework').multiselect({
  nonSelectedText: 'Select Class',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'400px'
 });
 
 $('#framework_form').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
   url:"membershipin.php",
   method:"POST",
   data:form_data,
   success:function(data)
   {
    $('#framework option:selected').each(function(){
     $(this).prop('selected', false);
    });
    $('#framework').multiselect('refresh');
    alert(data);
   }
  });
 });
 
 
});
</script>

		   
		   
		   
		   
		   
		   
		   <?php
		   
 if(isset($_POST['submit']))
                {
                        $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"icon/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }
						
						 $errors= array();
      $file_name1 = $_FILES['image1']['name'];
      $file_size1 =$_FILES['image1']['size'];
      $file_tmp1 =$_FILES['image1']['tmp_name'];
      $file_type1=$_FILES['image1']['type'];
      $file_ext1=strtolower(end(explode('.',$_FILES['image1']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext1,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size1 > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp1,"iconthumb/".$file_name1);
         echo "Success";
      }else{
         print_r($errors);
      }
	






 $act = '';
 foreach($_POST["act"] as $row)
 {
  $act .= $row . ', ';
 }
 $act = substr($act, 0, -2);







$name=$_POST['namea'];
$turl=$_POST['turl'];
 $ourl=$_POST['ourl'];
 $longdes=$_POST['longdes'];
$shdes=$_POST['shdes'];
	//echo $act=$_POST['act'];			
	 $genre=$_POST['genre'];
	 $year=$_POST['year'];		
 $star=$_POST['star'];				
 $fect=$_POST['fect'];	
                        
						
	

						
						
					
	
 $query="insert into movie_list(title,trailer_url,video_url,thumbnail,poster,longdes,shortdes,actor,genre,year,rating,feature)
values('$name','$turl','$ourl','$file_name1','$file_name','$longdes','$shdes','$act','$genre','$year','$star','$fect')";
  
mysqli_query($conn,$query);




						
						
						
						
						
						
						
						
						
						
			


	echo '<script language="javascript">';
echo 'swal(
  "Success!",

  "Data Added Successfully!",
  "success"
)';

echo '</script>';
		
		
		
		
			
		
		
		
		
		
							
				}
				

				?>

		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
				
				
	<script src="../assets13/jquery-1.12.4.min.js"></script>
<script src="../assets13/js/bootstrap.min.js"></script>
			
				
				
			

				
				
				
				
				
				
			


				
				
				
				
				
              </div><!-- /.box -->

              <!-- Form Element sizes -->
              
            <div class="col-md-6">
            <b>Preview:</b>
			</div>

             
            </div><!--/.col (left) -->
			
			
		

			  
			  
			  
			  
            </div><!--/.col (right) -->
          </div>   <!-- /.row -->
        </section><!-- /.content -->
		
      </div><!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
         
        </div>
       
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
   
     <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- jQuery UI 1.11.2 -->
   
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    
    <!-- Bootstrap 3.3.2 JS -->
   
    <!-- FastClick -->
  
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
 

    <!-- AdminLTE for demo purposes -->
   
 
  </body>
</html>
<?php
 }
 else{
	 header('Location:index.php');
	 exit();
 }
 
?>