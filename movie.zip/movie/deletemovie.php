<?php
 include("conn.php"); 
 
 ?>



 
 
 
 
 
 
 <?php
 
 
 
 
 
 
 $a=$_GET['id'];
$query="delete from movie_list where movie_id='$a'";
mysqli_query($conn,$query); 
echo '<script language="javascript">';
echo 'swal(
  "Success!",

  "Data Deleted Successfully!",
  "success"
)';

echo '</script>';





header('location:viewmovies.php');



 ?>