<?php



include("conn.php");
?>
<?php
session_start();
if(isset($_SESSION['username']))
{
	?>

<?php

$per=$_GET['name'];
$l=$_GET['inlabel'];
?>


											
											

											




<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gym Management System</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	  
	  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  
	  
	  <script src="sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="sweetalert/dist/sweetalert.css">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />

    <style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
    </style>
	<style type="text/css" media="print">
@page {
    size: auto;   /* auto is the initial value */
    margin: 0;  /* this affects the margin in the printer settings */
}
</style>
<style>
@media print {
    .control-group {
      display: none;
    }
}
</style>
<style>
	  .buttonx {
    background-color:#008CBA; /* Green */
    border: none;
    color: white;
    padding: 2px 19px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 2px 1px;
    cursor: pointer;
}
</style>


</head>

<body>
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                                <img src="images.jpg" style="width:50%; max-width:150px;">
								<h3>Gym Master</h3>
								
                            </td>
							
							
							
							<?php $s=date("Y-m-d");?></h5>
                            
							
							<?php
									
				$seq=" select status,date,name,inlabel, Count(*), SUM(amount) total FROM expense group by date,name,inlabel having name='$per' and inlabel='$l'";
				$nm=mysqli_query($conn,$seq);
				while($data = mysqli_fetch_assoc($nm)){
							
							$sta=$data['status'];
							
					 $n1d=$_SESSION['username'];		
					?>
							
							
							
							
                            <td>
                                Issue Date: <?php echo $s;?>
								<br>
								
								
								
									
                                Status: <?php echo $sta;?>		
								
                               
                            </td>
							
						
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="2">
                    <table>
				
					
                        <tr>

                            <td>
					Payment To<br>
GYM Master - GYM Management System
<br>
address,au
<br>
8899665544
<?php
$d="SELECT * FROM member where fname='$per'";
$gh=mysqli_query($conn,$d);
$cm=mysqli_fetch_assoc($gh);
$n1=$cm['address'];
$n2=$cm['city'];
$n3=$cm['state'];







?>
							</td>
                            
                            <td>
                             Bill To
<br>
<?php echo $per;?>
<br>
							  <?php echo $n1;?>
<br>
<?php echo $n2;?>
<br>
<?php echo $n3;?>
                               
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
           
			<br>
			
			<br>
            
            <tr class="heading">
                <td colspan="2">
                    Invoice Entries

                </td>
             
            </tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			
			 <br>
            <tr class="information">
			  <td colspan="3">
			 
			  
			  
			  
			  
			   <table class="table table-bordered">
			   <tr>
			   <th>#</th>
			    <th>Date</th>
				 <th>Entry</th>
				 <th>Price</th>
				 <th>Username</th>
				 </tr>
               <tr>
			    <?php
			  
			  ?>
			  
			   <td><?php echo 1;?></td>
			    <td><?php echo $data['date']?></td>
				<td><?php echo $data['inlabel']?></td>
			     <td><?php echo $data['total']?></td>
			      <td><?php echo $n1d;?></td>
			   </tr>
             
                
				</table>
				
				Grand Total :<?php echo $data['total']?>
				
				
				
				
				
				
				
				
				
				
				</td>
            </tr>
			
			
			
            
				
				
				
				
				
				
				
				
				
				
				<?php } ?>	
			
           
										
										
        </table>
		<div class="control-group">
		<div id="print">
		<a href="#" onclick="myFunction()"><i style="margin-right: 0.5em; color: #EEEEEE;" class="icon-home icon-4x"></i>Print</a>
		</div>
		</div>
<script>
function myFunction() {
    window.print();
}
</script>
		
		
    </div>
</body>
</html>
<?php
 }
 else{
	 header('Location:index.php');
	 exit();
 }
 
?>