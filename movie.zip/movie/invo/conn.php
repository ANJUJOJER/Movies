<?php
$conn=mysqli_connect("localhost","root","","calgy");
mysqli_select_db($conn,"calgy");

?>
