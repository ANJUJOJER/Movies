<?php



$conn=mysqli_connect("localhost","root","","movie");
mysqli_select_db($conn,"movie");
?>
