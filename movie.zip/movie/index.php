<?php

include("conn.php");


?>
<?php
session_start();

$type="";


?>
<html>
<head>
  <meta charset="UTF-8">
  <title></title>
  
  <!---<link rel="shortcut icon" href="//www.gstatic.com/recaptcha/admin/favicon.ico" type="image/x-icon"/>-->
       
  
     <!-- <link rel="stylesheet" href="css/style.css">-->
<script src="sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="sweetalert/dist/sweetalert.css">
  <style>
  html, body {
  border: 0;
  padding: 0;
  margin: 0;
  height: 100%;
}

body {
  background:#ffffff;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 16px;
}

form {
  background: white;
  width: 40%;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.7);
  font-family: lato;
  position: relative;
  color: ;
  border-radius: 10px;
}
form header {
  background: #007aff;
  padding: 30px 20px;
  color: white;
  font-size: 1.2em;
  font-weight: 600;
  border-radius: 10px 10px 0 0;
}
form label {
  margin-left: 20px;
  display: inline-block;
  margin-top: 30px;
  margin-bottom: 5px;
  position: relative;
}
form label span {
  color: #FF3838;
  font-size: 2em;
  position: absolute;
  left: 2.3em;
  top: -10px;
}
form input {
  display: block;
  width: 78%;
  margin-left: 20px;
  padding: 5px 20px;
  font-size: 1em;
  border-radius: 3px;
  outline: none;
  border: 1px solid #ccc;
}
form .help {
  margin-left: 20px;
  font-size: 0.8em;
  color: #777;
}
form button {
  position: relative;
  margin-top: 30px;
  margin-bottom: 30px;
  left: 50%;
  transform: translate(-50%, 0);
  font-family: inherit;
  color: white;
  background: #007aff;
  outline: none;
  border: none;
  padding: 5px 15px;
  font-size: 1.3em;
  font-weight: 400;
  border-radius: 3px;
  box-shadow: 0px 0px 10px rgba(51, 51, 51, 0.4);
  cursor: pointer;
  transition: all 0.15s ease-in-out;
}
form button:hover {
 background: #ff5252;
}

a {
    color:#99c9ff;
}

b{
	
	color:blue;
	
}
  
 </style> 
  
  
  
  
  
  
  
  
  
  
  
</head>

<body>
     
<form action="#" method="post">
  <header>Login</header>
  <label>Email</label>
 <input type="text" name="username" placeholder="Username">
 
  <label>Password</label>
  <input type="password" name="password" placeholder="*********">
  
  
  <br>
  
  
  <button name="submit">Login</button>

  
  </form>
 <?php

$user = "";
$pass = "";
$msg = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST'){

	$user = $_POST['username'];
	$pass = $_POST['password'];
		
			
		
		
	//unwanted HTML (scripting attacks)
	$user = htmlspecialchars($user);
	$pass = htmlspecialchars($pass);

	 $qry="select * from login ";
$result=mysqli_query($conn,$qry);
while($row=mysqli_fetch_assoc($result))
{
		$a = $row['username'];
		$b = $row['password'];
		$pos = $row['type'];
		
		
		
		
		
		
		
		
		
		
		if(($user == $a) AND ($pass == $b)){
			if($pos =="admin"){
				
				$_SESSION['username'] = $user;
				$_SESSION['admin'] = "log";
				
				
				echo '<script>
    setTimeout(function() {
        swal({
            title: "Wow!",
            text: "Login Successfully!",
            type: "success"
        }, function() {
            window.location = "index1.php";
        });
    }, 0);
</script>';
				
				
				
				
				
				
				
				
				
				
				
			 //echo '<script type="text/javascript">alert("Login Success");</script>';
			 
			 
			 //echo'<script>window.location.assign("index.php");</script>';
			 
			//echo '<script type="text/javascript">window.location.href="index.php";</script>';
				
				break;
			}
		
			
			
			
			
			
			
		}
		
		
		
		
	}
	
	
				echo '<script language="javascript">';
echo 'swal(
  "Oops...", "Login Failed!", "error")';

echo '</script>';
	


}
?>
						
						
	
  
</body>
</html>
