<?php

include("conn.php");

?>
<?php
session_start();
if(isset($_SESSION['username']))
{
	?>

<!DOCTYPE html>
<html>
  <head>
  
  
   <meta charset="UTF-8">
    <title>GYM Master - GYM Management System</title>
	<title>	<?php
$page =$_GET['page'];
$show_page= $_GET['page']; 
?>

</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	  
	  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	  
	  
	  <script src="sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="sweetalert/dist/sweetalert.css">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />



  </head>
 <body class="skin-blue">
    <div class="wrapper">
      
      <header class="main-header">
        <!-- Logo -->
        <a href="index.php" class="logo"><b>GYM</b>Management</a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
			  
            
			  
			  
			  
     
			  
			  
			  
			  
       
			  
			  
			  
			  
			  
			  
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="dist/img/admin.png" class="user-image" alt="User Image"/>
                  <span class="hidden-xs">Admin</span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="dist/img/admin.png" class="img-circle" alt="User Image" />
                    <p>
                     Admin
                      <small>Administrator</small>
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <li class="user-body">
                    
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    
                    <div class="pull-right">
                      <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
		
		
		
		
		
		
	<?php
		
       include("sidebar.php");
		?>
		
		
		
		
		
		
		
        <!-- /.sidebar -->
      </aside>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <b>Message</b>
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Message</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-3">
              <a href="compose.php" class="btn btn-primary btn-block margin-bottom">Compose</a>
              <div class="box box-solid">
                
                <div class="box-body no-padding">
                  <ul class="nav nav-pills nav-stacked">
				  <?php
				$df="SELECT COUNT(status) AS z FROM message where rto='admin' and status='NR'";
				  	$gh=mysqli_query($conn,$df);
$vb= mysqli_fetch_assoc($gh);
	$res=$vb['z'];			  
				  ?>
                    <li><a href="inbox.php"><i class="fa fa-inbox"></i> Inbox <span class="label label-primary pull-right"><?php echo $res;?></span></a></li>
                    <li><a href="sendmsg.php"><i class="fa fa-envelope-o"></i> Sent</a></li>
                   
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /. box -->
              <div class="box box-solid">
              
                
              </div><!-- /.box -->
            </div><!-- /.col -->
            <div class="col-md-9">
              <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Compose New Message</h3>
                </div><!-- /.box-header -->
				<form action="#" method="post"  enctype="multipart/form-data">
                <div class="box-body">
                  <div class="form-group">
				   <?php
				 	$stb = "SELECT DISTINCT fname FROM member";
														$re=mysqli_query($conn,$stb);
									


$stb1 = "SELECT DISTINCT fname FROM staff_details";
														$re1=mysqli_query($conn,$stb1);



$s = "SELECT DISTINCT fname FROM accountant";
														$r=mysqli_query($conn,$s);




									
				   ?>	
				   <label>Message To
				      <select id="dd1" name="stime"  style="width:650px;height:30px;">
				  
      <option value="">To</option>
      <option value="members">Members</option>
      <option value="staffmembers">Staff Members</option>
      <option value="accountant">Accountant</option>
	  <?php 
	  while($data = mysqli_fetch_assoc($re)){ 	?>
														<option value="<?php echo $data['fname'];?>"   > <?php echo $data['fname'];?>

														</option>
														
														<?php }?> 
														<?php
	  while($data1 = mysqli_fetch_assoc($re1)){ 	?>
														<option value="<?php echo $data1['fname'];?>"   > <?php echo $data1['fname'];?>

														</option>
														
														<?php }?> 
	  
	  	<?php
	  while($d= mysqli_fetch_assoc($r)){ 	?>
														<option value="<?php echo $d['fname'];?>"   > <?php echo $d['fname'];?>

														</option>
														
														<?php }?> 
     </select></label>
                    <!--<input  type="text"  style="width:450px;height:30px;"/> </label>--->
                  </div>
				  
				  
				  
		                 <div class="form-group">
				   <?php
				 	$st= "SELECT DISTINCT name FROM class";
														$ro=mysqli_query($conn,$st);
									


									
				   ?>	
				   <label>Select Class
				      <select id="dd1" name="stime1"  style="width:650px;height:30px;">
				  
      <option value="All">All</option>
      
	  <?php 
	  while($data = mysqli_fetch_assoc($ro)){ 	?>
														<option value="<?php echo $data['name'];?>"   > <?php echo $data['name'];?>

														</option>
														
														<?php }?> 
												
     </select></label>
                    <!--<input  type="text"  style="width:450px;height:30px;"/> </label>--->
                  </div>
				  
				  		  
				  
				  
				  
				  
				  
				  
                  <div class="form-group">
				  <label>Subject</label>
                    <input class="form-control" name="sub" placeholder="Subject:" />
                  </div>
                  <div class="form-group">
                    <textarea id="compose-textarea" name="content" class="form-control" style="height: 300px">
                      
                    </textarea>
                  </div>
                  <div class="form-group">
                    <div class="btn btn-default btn-file">
                      <i class="fa fa-paperclip"></i> Attachment
                      <input type="file" name="photo"/>
                    </div>
                    <p class="help-block">Max. 32MB</p>
                  </div>
                </div><!-- /.box-body -->
                <div class="box-footer">
                  <div class="pull-right">
                  
                    <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Send</button>
                  </div>
				  </form>
				  <?php
				  
				  if(isset($_POST["submit"]))
{
		
						 $errors= array();

      $file_name = $_FILES['photo']['name'];
      $file_size =$_FILES['photo']['size'];
      $file_tmp =$_FILES['photo']['tmp_name'];
      $file_type=$_FILES['photo']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['photo']['name'])));

      $expensions= array("jpeg","jpg","png");

      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG
file.";

      }

      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }

      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"message/photo/".$file_name);
      }else{
         print_r($errors);
      }
						$name=$_SESSION['username'];
				   $s=$_POST['stime'];
				   $s1=$_POST['stime1'];
				  
				  $sub=$_POST['sub'];
				  
				 $con=$_POST['content'];
				  
				   $sf=date("Y-m-d");
				   	  


date_default_timezone_set("Asia/Calcutta");
$t=date("H:i:s");


				 	$query="insert into message(sender,rto,class,subject,content,date,time,attachment,status) values('$name','$s','$s1','$sub','$con','$sf','$t','$file_name','NR')";
  
mysqli_query($conn,$query);




						
						
						
						
						
						
						
						
						
						
			


	echo '<script language="javascript">';
echo 'swal(
  "Success!",

  "Message Send Successfully!",
  "success"
)';

echo '</script>';
		 
				  
}
				  
				  
				  ?>
                  <button class="btn btn-default"><i class="fa fa-times"></i> Discard</button>
                </div><!-- /.box-footer -->
              </div><!-- /. box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
        
        </div>
     
      </footer>
    </div><!-- ./wrapper -->

   <script src="dist/js/app.min.js" type="text/javascript"></script>
  </body>
</html>
<?php
 }
 else{
	 header('Location:index.php');
	 exit();
 }
 
?>