<html>
<head>

		<script src="sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="sweetalert/dist/sweetalert.css">
<script
src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script
src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js">
        </script>
<script>
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted)
disableBack() }
    });
</script>
</head>




<?php  
  
  
session_start();//session is a way to store information (in variables) to be used across multiple pages.
 unset($_SESSION['username']);    
session_destroy();  

//echo"<script>alert('You are Logged Out')</script>"; 
echo"<script>window.location.assign('index.php');</script>";
?>  


<script>
var url = window.location.href;
window.history.go(-window.history.length);
window.location.href = url;

</script>
<script>

public class NoCacheAttribute : ActionFilterAttribute
{  
  public override void OnResultExecuting(ResultExecutingContext filterContext)
  {
      filterContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
      filterContext.HttpContext.Response.Cache.SetValidUntilExpires(false);
      filterContext.HttpContext.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);
      filterContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
      filterContext.HttpContext.Response.Cache.SetNoStore();

      base.OnResultExecuting(filterContext);
  }
}

</script>








</html>